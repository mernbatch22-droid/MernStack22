import React from 'react'
import SecondUseCaseOfUseRef from './SecondUseCaseOfUseRef.jsx'
// import FirstUseCaseOfUseRef from "./FirstUseCaseOfUseRef.jsx"
function App() {
  return (
    <div>
      {/* <FirstUseCaseOfUseRef/> */}
      <SecondUseCaseOfUseRef />
    </div>
  )
}

export default App