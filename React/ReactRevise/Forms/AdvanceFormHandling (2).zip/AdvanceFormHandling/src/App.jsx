import AdvanceForm from "./components/AdvanceForm.jsx"
function App() {

  return (
    <div>
      <AdvanceForm />

    </div>
  )
}

export default App