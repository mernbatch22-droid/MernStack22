import BasicForm from "./components/BasicForm.jsx"
function App() {

  return (
    <div>
      <BasicForm />

    </div>
  )
}

export default App